﻿  import { Component } from '@angular/core';

@Component({
    selector:'mm-movies',
    templateUrl: 'app/home/welcome.component.html'//using linked template
})
export class WelcomeComponent {
    public pageTitle: string = 'Welcome';
}
