﻿export interface IMovie {//I is a convention for adding interface
    movieId: number;
    movieStar: string;
    movieName: string;
    releaseDate: string;
    price: number;
    starRating: number;
    imageUrl: string;
}